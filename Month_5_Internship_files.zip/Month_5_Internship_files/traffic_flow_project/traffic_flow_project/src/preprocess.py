
import pandas as pd

def load_and_preprocess(path, timestamp_col='timestamp'):
    df = pd.read_csv(path, parse_dates=[timestamp_col])
    # basic cleaning
    df = df.sort_values(timestamp_col)
    df = df.dropna(subset=['vehicle_count'])
    return df
