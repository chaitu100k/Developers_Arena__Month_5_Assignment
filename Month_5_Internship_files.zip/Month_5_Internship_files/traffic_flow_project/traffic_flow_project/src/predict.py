
import joblib
import pandas as pd

def predict(model_path, X):
    model = joblib.load(model_path)
    return model.predict(X)
